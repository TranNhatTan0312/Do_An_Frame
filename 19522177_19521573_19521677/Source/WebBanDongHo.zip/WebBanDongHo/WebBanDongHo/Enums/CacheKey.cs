﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebBanDongHo.Enums
{
    public enum CacheKey
    {
        Categories,
        KhachHang,
        KeyWords,
        TinDang
    }
}
